</div>
            <!-- end div class col-md-10 -->
         </div>
         <!-- end div class row -->
      </div>
      <!-- end div class container -->
      
      
      
      
      
      
      <!-- start footer -->
      <footer class="footer">
         <div class="container">
            <div class="row">
               <div class="col-sm-3">
                  <h4 class="title">About</h4>
                  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin suscipit, libero a molestie consectetur, sapien elit lacinia mi.</p>
                  <ul class="social-icon">
                     <a href="#" class="social"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                     <a href="#" class="social"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                     <a href="#" class="social"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                     <a href="#" class="social"><i class="fa fa-youtube-play" aria-hidden="true"></i></a>
                     <a href="#" class="social"><i class="fa fa-google" aria-hidden="true"></i></a>
                     <a href="#" class="social"><i class="fa fa-dribbble" aria-hidden="true"></i></a>
                  </ul>
               </div>
               <div class="col-sm-3">
                  <h4 class="title">Site Map</h4>
                  <span class="acount-icon">          
                  <a href="#"><i class="fa fa-link" aria-hidden="true"></i> https://www.facebook.com/profile.php?id=100048034292912</a>
                  <a href="#"><i class="fa fa-link" aria-hidden="true"></i> Link</a>
                  <a href="#"><i class="fa fa-link" aria-hidden="true"></i> Link</a>
                  <a href="#"><i class="fa fa-link" aria-hidden="true"></i> Link</a>           
                  </span>
               </div>
               <div class="col-sm-3">
                  <h4 class="title">Category</h4>
                  <div class="category">
                     <a href="#">Mobiles</a>
                     <a href="#">computers</a>
                     <a href="#">Toys</a>
                     <a href="#">Make-up</a>
                     <a href="#">Printers</a>
                     <a href="#">Perfumes</a>
                              
                  </div>
               </div>
               
               <div class="col-sm-3">
                  <h4 class="title">Payment Methods</h4>
                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                  <ul class="payment">
                     <li><a href="#"><i class="fa fa-cc-amex" aria-hidden="true"></i></a></li>
                     <li><a href="#"><i class="fa fa-credit-card" aria-hidden="true"></i></a></li>
                     <li><a href="#"><i class="fa fa-paypal" aria-hidden="true"></i></a></li>
                     <li><a href="#"><i class="fa fa-cc-visa" aria-hidden="true"></i></a></li>
                  </ul>
               </div>
            </div>
            <hr>
            <div class="row text-center"> <h3>© 2020. MOHAMMED HAMADA.</h3></div>
         </div>
      </footer>
      <!-- end footer -->
      
      
      <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
   </body>
</html>