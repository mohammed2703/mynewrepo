</div>
        </div>
    </div>
    
    <div style="margin-top: 2%;text-align: center;padding: 3%;background: black;color: white;">
        <p>All copyrights to itgate 2020</p>
    </div>


    <script src="../js/jquery.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
  </body>
</html>